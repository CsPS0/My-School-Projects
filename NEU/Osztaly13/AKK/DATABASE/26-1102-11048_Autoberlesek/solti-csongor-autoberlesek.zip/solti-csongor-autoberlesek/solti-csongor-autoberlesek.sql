DROP DATABASE IF EXISTS `autoberlesek`;
CREATE DATABASE IF NOT EXISTS `autoberlesek`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_hungarian_ci;

USE `autoberlesek`;

CREATE TABLE `autok` (
  `id` int NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `gyarto` varchar(10) DEFAULT NULL,
  `tipus` varchar(21) DEFAULT NULL,
  `szin` varchar(21) DEFAULT NULL,
  `loero` int DEFAULT NULL,
  `fogyasztas` float DEFAULT NULL
);

CREATE TABLE `ugyfelek` (
  `id` int NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `nem` varchar(5) DEFAULT NULL,
  `vnev` varchar(30) DEFAULT NULL,
  `knev` varchar(30) DEFAULT NULL,
  `irsz` int DEFAULT NULL,
  `varos` varchar(30) DEFAULT NULL,
  `cím` varchar(30) DEFAULT NULL,
  `szuletet` date DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS `berlesek` (
  `auto_id` INT NOT NULL,
  `ugyfel_id` INT NOT NULL,
  `elvitte` DATETIME NOT NULL,
  `visszahozta` DATETIME DEFAULT NULL,
  PRIMARY KEY (`auto_id`, `ugyfel_id`),
  CONSTRAINT `fk_berlesek_ugyfel` FOREIGN KEY (`ugyfel_id`) REFERENCES `ugyfelek` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

INSERT INTO `autok` (`id`, `gyarto`, `tipus`, `szin`, `loero`, `fogyasztas`) VALUES
(1, 'BMW', '120D', 'Tanzanit Kék metál', 177, 7.6),
(2, 'Peugeot', '207 SW 1.6 HDI', 'zöld', 109, 21.1),
(3, 'BMW', '530 XD', 'Portimao Kék metál', 235, 18),
(4, 'Mercedes', 'CLK DTM AMG', 'patagónia-vörös metál', 582, 4),
(5, 'VW', 'Golf GTI', 'Kings-vörös metál', 200, 6.9),
(6, 'Honda', 'Jazz 1.4I CVT', 'fehér', 83, 14.5),
(7, 'Ford', 'Mondeo 2.5T', 'fekete', 220, 7.5),
(8, 'Land Rover', 'Range Rover Sport 3.6', 'sötétszürke', 272, 9.2),
(9, 'BMW', 'X3 3.0 SD', 'Riviera Kék', 286, 6.6),
(10, 'Bentley', 'Continental GT', 'fekete', 560, 4.9),
(11, 'Jaguar', 'S-TYPE R', 'ezüstmetál', 395, 5.6),
(12, 'Corvette', 'Z06', 'zöld', 505, 3.7),
(13, 'Fiat', 'Panda 4x4', 'zöld', 60, 20),
(14, 'Honda', 'City', 'narancssárga', 201, 6.6),
(15, 'Opel', 'Astra', 'kék', 150, 10.2),
(16, 'Skoda', 'Octavia RS', 'Atlanti kék', 170, 8.5),
(17, 'Volvo', 'S60R', 'Denim kék', 300, 5.7),
(18, 'Volvo', 'S80 3.2', 'Platinaszürke', 238, 8),
(19, 'Fiat', 'Grande Punto', 'Italia kék', 90, 11.9),
(20, 'Nissan', 'X-Trail 2.2', 'szürke', 136, 11.5);



INSERT INTO `ugyfelek` (`id`, `nem`, `vnev`, `knev`, `irsz`, `varos`, `cím`, `szuletet`) VALUES
(1, 'nő', 'Angyal', 'Franciska', 2234, 'Maglód', 'Síp utca 5.', '1932-04-23'),
(2, 'nő', 'Smitt', 'Gitta', 3535, 'Miskolc', 'Dózsa György út 23.', '1932-05-19'),
(3, 'nő', 'Kassza', 'Robi', 8308, 'Zalahaláp', 'Rákóczi út 36.', '1933-03-27'),
(4, 'nő', 'Szigeti', 'Malcsi', 4141, 'Furta', 'Tompa u. 67.', '1934-03-21'),
(5, 'férfi', 'Sebök', 'Szebasztián', 3794, 'Ziliz', 'Baross tér 24.', '1934-07-07'),
(6, 'férfi', 'Majoros', 'Oszkár', 9913, 'Döröske', 'Kis Diófa u. 95.', '1934-08-16'),
(7, 'nő', 'Csontos', 'Treszka', 5241, 'Abádszalók', 'Apor Péter u. 15.', '1934-09-01'),
(8, 'nő', 'Bernát', 'Izabella', 7133, 'Fadd', 'Tas vezér u. 48.', '1934-10-30'),
(9, 'nő', 'Imre', 'Karolina', 6066, 'Tiszaalpár', 'Király u. 86.', '1934-11-01'),
(10, 'férfi', 'Bernát', 'Tétény', 8543, 'Gecse', 'Kárpát u. 12.', '1935-02-15'),
(11, 'nő', 'Borbély', 'Dorina', 2426, 'Baracs', 'Erzsébet krt. 57.', '1935-02-19'),
(12, 'nő', 'Fenyvesi', 'Dzsenifer', 8248, 'Veszprémfajsz', 'Rákóczi út 99.', '1935-12-12'),
(13, 'nő', 'Vida', 'Adél', 3078, 'Kisterenye', 'Apáczai Csere János u. 78.', '1936-01-06'),
(14, 'férfi', 'Dömötör', 'Medárd', 9322, 'Rábatamási', 'Wesselényi u. 27.', '1936-01-23'),
(15, 'férfi', 'Danka', 'Alexander', 9339, 'Kapuvár', 'Wesselényi u. 56.', '1936-07-01'),
(16, 'férfi', 'Szüts', 'Ákos', 8831, 'Liszó', 'Kálmán Imre u. 88.', '1937-06-13'),
(17, 'nő', 'Vincze', 'Kinga', 2343, 'Kiskunlacháza', 'Erzsébet krt. 1.', '1937-07-14'),
(18, 'nő', 'Hermann', 'Ivett', 3347, 'Balaton', 'Erzsébet tér 1.', '1937-10-06'),
(19, 'nő', 'Szalay', 'Katinka', 8649, 'Balatonberény', 'Nánási út 53.', '1937-12-08'),
(20, 'férfi', 'Kerekes', 'Adél', 7443, 'Somogyjád', 'Eötvös út 7.', '1938-04-21'),
(21, 'nő', 'Balogh', 'Kriszta', 9800, 'Vasvár', 'Belgrád rkp. 86.', '1938-06-14'),
(22, 'nő', 'Magyar', 'Anna', 3433, 'Nyékládháza', 'Dózsa György út 57.', '1938-06-23'),
(23, 'nő', 'Berényi', 'Liliána', 8932, 'Pókaszepetk', 'Csavargyár u. 64.', '1939-03-05'),
(24, 'nő', 'Biró', 'Brigitta', 7532, 'Hencse', 'Eötvös út 58.', '1939-06-05'),
(25, 'férfi', 'Kurucz', 'Béla', 8312, 'Balatonederics', 'Rákóczi út 48.', '1939-09-13'),
(26, 'férfi', 'Albert', 'Andor', 7696, 'Ófalu', 'Kossuth Lajos u. 16.', '1939-10-30'),
(27, 'férfi', 'Takáts', 'Endre', 3134, 'Piliny', 'Apáczai Csere János u. 31.', '1940-01-06'),
(28, 'nő', 'Lukáts', 'Henrietta', 2426, 'Baracs', 'Erzsébet krt. 92.', '1940-01-25'),
(29, 'nő', 'Földesi', 'Viktória', 3024, 'Selyp', 'Munkácsy Mihály út 67.', '1940-01-26'),
(30, 'nő', 'Baranyi', 'Zita', 3246, 'Mátraderecske', 'Erzsébet tér 24.', '1940-02-24'),
(31, 'férfi', 'Györffi', 'Loránt', 8469, 'Kamond', 'Izabella u. 80.', '1940-03-26'),
(32, 'nő', 'Saághy', 'Erzsébet', 8627, 'Kötcse', 'Nánási út 77.', '1940-05-01'),
(33, 'férfi', 'Vince', 'József', 9725, 'Kőszegdoroszló', 'Belgrád rkp. 31.', '1940-05-12'),
(34, 'nő', 'Bodor', 'Béla', 7839, 'Zaláta', 'Piroska u. 9.', '1940-06-08'),
(35, 'férfi', 'Berta', 'Gergely', 5820, 'Mezőhegyes', 'Király u. 49.', '1941-04-13'),
(36, 'férfi', 'Orosz', 'Titusz', 9523, 'Szergény', 'Victor Hugo u. 26.', '1941-11-25'),
(37, 'nő', 'Virágh', 'Melinda', 9098, 'Mezőörs', 'Bécsi utca 48.', '1941-12-01'),
(38, 'férfi', 'Sinku', 'Richárd', 8644, 'Fonyód', 'Nánási út 14.', '1942-01-11'),
(39, 'nő', 'Szatmáry', 'Vanessza', 6753, 'Szeged', 'Nagytétényi út 41.', '1942-08-12'),
(40, 'nő', 'Kocsis', 'Lilla', 9634, 'Lócs', 'Victor Hugo u. 29.', '1942-08-14'),
(41, 'férfi', 'Rigó', 'Bálit', 8348, 'Zalameggyes', 'Izabella u. 16.', '1942-12-06'),
(42, 'nő', 'Gerencsér', 'Zsuzsa', 9662, 'Mesterháza', 'Victor Hugo u. 17.', '1943-01-11'),
(43, 'férfi', 'Forgách', 'Loránd', 1088, 'Budapest', 'Csabai kapu 69.', '1943-02-18'),
(44, 'férfi', 'Müller', 'János', 7305, 'Mecsekjánosi', 'Szilágyi Erzsébet fasor 75.', '1943-05-08'),
(45, 'férfi', 'Kádár', 'Viktor', 3712, 'Sajósenye', 'Szent Gellért tér 90.', '1943-07-10'),
(46, 'nő', 'Bognár', 'Erzsébet', 8777, 'Hosszúvölgy', 'Kálmán Imre u. 92.', '1943-08-06'),
(47, 'nő', 'Angyal', 'Emese', 8921, 'Zalaszentiván', 'Csavargyár u. 7.', '1944-09-06'),
(48, 'nő', 'Szigeti', 'Nóra', 4833, 'Tiszaadony', 'Bem rakpart 59.', '1944-09-29'),
(49, 'nő', 'Kiss', 'Adél', 3792, 'Sajóbábony', 'Baross tér 95.', '1946-11-04'),
(50, 'nő', 'Kálmán', 'Erzsébet', 8239, 'Tihanyrév', 'Rákóczi út 15.', '1947-01-02');



INSERT INTO `berlesek` (`auto_id`, `ugyfel_id`, `elvitte`, `visszahozta`) VALUES
(1, 18, '2023-04-07 14:40:53', '2023-04-23 14:40:53'),
(3, 38, '2023-06-01 13:42:16', NULL),
(3, 50, '2023-04-27 21:33:59', '2023-05-16 21:33:59'),
(6, 11, '2023-04-03 14:01:19', '2023-04-14 14:01:19'),
(6, 27, '2023-04-10 15:18:31', '2023-04-28 15:18:31'),
(6, 48, '2023-04-25 09:37:48', '2023-05-20 09:37:48'),
(9, 23, '2023-04-05 20:46:14', '2023-04-25 20:46:14'),
(10, 44, '2023-05-02 04:43:56', '2023-05-14 04:43:56'),
(11, 1, '2023-04-25 04:58:05', '2023-05-13 04:58:05'),
(13, 25, '2023-04-06 11:30:56', '2023-04-28 11:30:56'),
(16, 7, '2023-05-28 00:25:41', NULL),
(16, 9, '2023-04-21 14:25:25', '2023-05-16 14:25:25'),
(16, 16, '2023-04-03 08:29:54', '2023-04-26 08:29:54'),
(16, 18, '2023-04-05 03:36:02', '2023-04-10 03:36:02'),
(16, 26, '2023-04-04 22:54:04', '2023-04-21 22:54:04'),
(17, 40, '2023-04-20 05:26:24', NULL),
(18, 1, '2023-04-19 23:30:53', '2023-05-15 23:30:53'),
(18, 15, '2023-04-11 12:13:38', '2023-04-15 12:13:38'),
(18, 25, '2023-04-27 05:11:53', '2023-05-19 05:11:53'),
(20, 19, '2023-04-17 04:00:31', '2023-05-15 04:00:31');

CREATE OR REPLACE VIEW `gyartok` AS
SELECT DISTINCT `gyarto`
FROM `autok`
ORDER BY `gyarto` DESC;

SELECT `gyarto` FROM `gyartok` ORDER BY `gyarto` ASC;

SELECT `gyarto`, `szin`, `loero`
FROM `autok`
WHERE `loero` BETWEEN 201 AND 300
  AND `gyarto` IN ('BMW', 'Honda', 'Ford')
  AND `szin` LIKE '%kék%'
ORDER BY `loero` ASC;

CREATE OR REPLACE VIEW `kintlevo` AS
SELECT a.`gyarto`, a.`tipus`, u.`vnev`, u.`knev`, b.`elvitte`
FROM `berlesek` b
JOIN `autok` a ON b.`auto_id` = a.`id`
JOIN `ugyfelek` u ON b.`ugyfel_id` = u.`id`
WHERE b.`visszahozta` IS NULL
ORDER BY b.`elvitte` ASC;

CREATE USER IF NOT EXISTS 'ugyintezo'@'%' IDENTIFIED BY 'ugyintezo';
CREATE USER IF NOT EXISTS 'elemzo'@'%' IDENTIFIED BY 'elemzo';
GRANT SELECT ON `autoberlesek`.`kintlevo` TO 'ugyintezo'@'%';

CREATE OR REPLACE VIEW `gyarto_db` AS
SELECT `gyarto`, COUNT(*) AS `db`
FROM `autok`
GROUP BY `gyarto`
ORDER BY `gyarto` ASC;

CREATE OR REPLACE VIEW `atlagfgoyasztas` AS
SELECT `gyarto`, CONCAT(ROUND(AVG(`fogyasztas`), 1), ' liter/100km') AS `atlag`
FROM `autok`
GROUP BY `gyarto`
ORDER BY `gyarto` ASC;

SELECT CONCAT(u.`vnev`, ' ', u.`knev`) AS `teljes_nev`, COUNT(*) AS `kolcsonzesek_szama`
FROM `berlesek` b
JOIN `ugyfelek` u ON b.`ugyfel_id` = u.`id`
GROUP BY u.`id`, u.`vnev`, u.`knev`
HAVING COUNT(*) > 1
ORDER BY `teljes_nev` DESC;

CREATE ROLE IF NOT EXISTS `statisztika`;
GRANT SELECT ON `autoberlesek`.`kintlevo` TO `statisztika`;
GRANT SELECT ON `autoberlesek`.`gyarto_db` TO `statisztika`;
GRANT SELECT ON `autoberlesek`.`atlagfgoyasztas` TO `statisztika`;
GRANT `statisztika` TO 'elemzo'@'%';
SET DEFAULT ROLE `statisztika` TO 'elemzo'@'%';

CREATE USER IF NOT EXISTS 'admin'@'%' IDENTIFIED BY 'admin';
GRANT SELECT, INSERT, UPDATE ON `autoberlesek`.`autok` TO 'admin'@'%';
GRANT SELECT, INSERT, UPDATE ON `autoberlesek`.`ugyfelek` TO 'admin'@'%';
GRANT SELECT, INSERT, UPDATE ON `autoberlesek`.`berlesek` TO 'admin'@'%';

UPDATE `ugyfelek` SET `vnev` = 'Kasza' WHERE `id` = 3;

INSERT INTO `berlesek` (`auto_id`, `ugyfel_id`, `elvitte`, `visszahozta`) VALUES
(3, 7, '2023-06-06 11:25:44', NULL),
(11, 21, '2023-06-06 17:11:34', NULL);

ALTER TABLE `autok` ADD COLUMN `minosites` VARCHAR(10) DEFAULT 'kiváló';

ALTER TABLE `berlesek`
ADD CONSTRAINT `fk_berlesek_auto`
FOREIGN KEY (`auto_id`) REFERENCES `autok` (`id`)
ON DELETE RESTRICT ON UPDATE CASCADE;

DELETE FROM `berlesek` WHERE `ugyfel_id` IN (SELECT `id` FROM `ugyfelek` WHERE `varos` = 'Vasvár');
DELETE FROM `ugyfelek` WHERE `varos` = 'Vasvár';
