CREATE DATABASE IF NOT EXISTS `autoberlesek`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_hungarian_ci;
