<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ChocolateController extends Controller
{
    public function index() {
        $db = DB::table('chocolate');

        return response() json([
            "db"=>$db->get()
        ]);
    }

    public function show(int $id) {
        $db = DB::table('chocolate')->where('id', $id)->first();

        if (!$db) {
            return response()->json([
                'message' => 'A csokoládé nem található'
            ], 404);
        }
    }
}
