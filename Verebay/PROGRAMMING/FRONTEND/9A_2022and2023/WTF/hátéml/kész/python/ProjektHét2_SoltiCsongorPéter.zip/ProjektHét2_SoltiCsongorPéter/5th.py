num = int(input('Adj meg egy páros számot 1 és 9 között:'))

if num == (2, 4, 6, 8,):
    print('Szép hogy tudod a számokat!')
elif num == (1, 3, 5, 7, 9):
    print('Azt modtam párosat, de nem modtam hogy páratlant!')