from random import randrange


for number in range(1, 12):
    randrange(number)