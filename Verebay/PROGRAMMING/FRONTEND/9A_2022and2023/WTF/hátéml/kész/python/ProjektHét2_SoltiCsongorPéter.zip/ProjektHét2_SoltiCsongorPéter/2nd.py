for number in range(10, 0, -1):
    print(number)