for number in range(10, 0, -1):
    if number % 2 == 1:
        print(number)