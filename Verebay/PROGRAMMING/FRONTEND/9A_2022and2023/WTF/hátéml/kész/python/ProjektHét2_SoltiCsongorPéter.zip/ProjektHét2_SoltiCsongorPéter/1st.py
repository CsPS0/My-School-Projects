for number in range(1, 10):
    if number % 2 == 0:
        print(number)